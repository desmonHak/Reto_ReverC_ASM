#include <string.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv){
    if (argc <= 1){
        puts("Modo de uso:");
        puts("./solution.elf <1/2/3/4> <hash md5 obtenido>");
        puts("<1/2/3/4> es el numeo del hash obtenido, 1 para hash1 y consecutivamente.");
        puts("<hash md5 obtenido> sera el hash que usted obtuvo.");
        exit(0);
    }
    else {
        unsigned char option_hash = atoi(argv[1]);
        int Hash_status = 0xff;
        switch (option_hash)
        {
        case 1:
            Hash_status = strcmp("f3efbf0af57106310a301d85a4fc8976", argv[2]);
            break;
        case 2:
            Hash_status = strcmp("117399eaab70b8181e2af61b3bed50d6", argv[2]);
            break;
        case 3:
            Hash_status = strcmp("f5ce2c9f4a3e6aa21c786dba5301224c", argv[2]);
            break;
        case 4: 
            Hash_status = strcmp("d26d410950a1b0b18893045e04fa7b2e", argv[2]);
            break;
        default:
            puts("Esta opcion no se encuentra en el rango de 1 a 4.");
            exit(1);
            break;
        }
        if (Hash_status == 0) printf("[+] Hash%d correcto\n", option_hash);
        else  printf("[!] Hash%d incorrecto. :(\n", option_hash);
        
    }

    return 0;
}