/* 
 *  By: Desmon  
 *  Github: https://github.com/desmonHak
 *  
 *  Tags: #Reversing #Assemblyx86_intel #C #CTF #Linux #32bits
 *  Description: 
 *      Simple CTF de reversing, usted puede compilar el reto con lo siguiente;
 *  gcc -O0 -masm=intel -static  -z execstack -m32  -ggdb -no-pie -fno-stack-protector poorboy.c -o poorboy.elf
 * 
 *  -O0                  = cero optimizaciones
 *  -static              = codigo+lib statico (no usado)
 *  -masm=intel          = ensamblador con sitaxis intel 
 *  -z execstack         = stack ejecutable
 *  -m32                 = codigo de 32bits
 *  -ggdb                = con informacion de depuracion para gdb (no usado)
 *  -fno-stack-protector = sin proteciones de stack
 * 
 *  Para obtener la solucion compile añadiendo "-D __SEE_ALL_FLAG__" a lo anterior
 *  y vuelva a ejecutar el comando. 
 *  Otra manera es descomprimir flags.zip donde se encuentra las soluciones y el codigo del programa.
 *  Ademas de una version del mismo ya compilada para dar las soluciones directamente
 * 
 */

#ifdef __SEE_ALL_FLAG__
#define __FLAG4_SEE__
#define __FLAG3_SEE__
#define __FLAG2_SEE__
#define __FLAG1_SEE__
#endif

typedef signed char              i8;
typedef unsigned char           ui8;
typedef signed short int        i16;
typedef unsigned short int     ui16;
typedef signed long int         i32;
typedef unsigned long int      ui32;
typedef signed long long int    i64;
typedef unsigned long long     ui64;

typedef ui8   db;   // 8  bits = 1 Bytes
typedef ui16  dw;   // 16 bits = 2 Bytes
typedef ui32  dd;   // 32 bits = 4 Bytes
typedef ui64  dq;   // 64 bits = 8 Bytes

typedef struct _int8_t {
    i8        _int8_t:8;
} _int8_t;  // (db)
typedef struct _uint8_t {
    db      _uint8_t:8;
} _uint8_t; // (db)
typedef struct _int16_t {
    i16       _int16_t:16;
} _int16_t; // (dw)
typedef struct _uint16_t {
    dw      _uint16_t:16;
} _uint16_t; // (dw)
typedef struct _int32_t {
    i32       _int32_t:32;
} _int32_t; // (dd)
typedef struct _uint32_t {
    dd     _uint32_t:32;
} _uint32_t; // (dd)
typedef struct _int64_t {
    i64       _int64_t:64;
} _int64_t; // (dq)
typedef struct _uint64_t {
    dq     _uint64_t:64;
} _uint64_t; // (dq)

#define UI8(value)  (_uint8_t)  {value}
#define UI16(value) (_uint16_t) {value}
#define UI32(value) (_uint32_t) {value}
#define UI64(value) (_uint64_t) {value}
#define I8(value)   (_int8_t)   {value}
#define I16(value)  (_int16_)   {value}
#define I32(value)  (_int32_)   {value}
#define I64(value)  (_int64_)   {value}

#include <stdio.h>
#include <sys/ptrace.h>
#include <stdlib.h>

ui8 stack[] __attribute__ ((section("flag_2"))) = {
    // hash(md5): 117399eaab70b8181e2af61b3bed50d6
    // text input for hash:
    'A','A','B','B','A','A',
    'A','A','B','B','A','A',
    'A','A','A','A','B','B',
    'A','A','A','A','B','B',    
    'B','B','B','B','B','B',
    'B','B','B','B','B','B',
    // representacion de: https://es.wikipedia.org/wiki/Emblema_hacker
};

/*
nasm -f elf32 -o exit1.o exit1.asm
ld -m elf_i386 -o exit1 exit1.o
./exit1
objdump -M intel -d exit1

section .data
section .bss
section .text
    global _start   
    _start:           
        xor eax, 0     
        mov al, 1    
        int 0x80     
*/
ui8 flag_1[] = "f3efbf0af57106310a301d85a4fc8976\n";
int __attribute__((noreturn)) (*fun_ptr)();

void __attribute__((constructor)) __init__(){
    puts("void __attribute__((constructor)) __init__();");
    if (ptrace(PTRACE_TRACEME, 0) < 0) {
        puts("Este processo esta siendo debuggeado :'(\n");
        exit(1);
    } else {
        puts("Proceso sin debugg :), que funcion identifica esto?(flag3)");
    }
    #ifdef __FLAG3_SEE__ || __SEE_ALL_FLAG__
    puts("funcion usada para debuggear:");
    puts("\033[91m ptrace");
    puts("\033[92mflag3\033[39m: hash(\033[95mmd5\033[39m): \033[96m f5ce2c9f4a3e6aa21c786dba5301224c\033[39m");
    #endif
}

/* 
 *
 *  string objetivo a contener: fl1g4_?\0 
 * 
 *  string en hex: 
 *      0x66, 0x6c, 0x31, 
 *      0x67, 0x34, 0x5f,
 *      0x3f, 0x00
 * 
 *  text encriptado en xor: 
 *      0x1f, 0x3, 0x44, 
 *      0x38, 0x57, 0x3e, 
 *      0x51, 0x5f, 
 * 
 *  clave de encriptado: you_can_see_me?
 * 
 */
static ui8 flag4[] = {
    0x1f, 0x3, 0x44, 
    0x38, 0x57, 0x3e, 
    0x51, 0x5f, 
};

void __attribute__((destructor)) __end__(){
    puts("void __attribute__((destructor)) __end__();");
    puts("bye mundo cruel");

    ui8 key[] = "you_can_see_me?";

    #ifdef __FLAG4_SEE__ || __SEE_ALL_FLAG__
    for (ui8 i = 0; i < sizeof(flag4)/sizeof(ui8); i++) printf("0x%x, ",flag4[i]);
    printf("\n%s\n", flag4);
    #endif

    for(ui8 i = 0; i < sizeof(flag4)/sizeof(ui8); i++)
        flag4[i] ^= key[i % sizeof(key)/sizeof(ui8)];

    #ifdef __FLAG4_SEE__ || __SEE_ALL_FLAG__
    for (ui8 i = 0; i < sizeof(flag4)/sizeof(ui8); i++) printf("0x%x, ",flag4[i]);
    printf("\n\033[91m %s\n", flag4);
    puts("\033[92mflag4\033[39m: hash(\033[95mmd5\033[39m): \033[96m d26d410950a1b0b18893045e04fa7b2e\033[39m");
    #endif
}

int main(){
    // \xb8\x04\x00\x00\x00\xbb\x01\x00\x00\x00\xb9\x10\xc0\x04\x08\xba\x0e\x00\x00\x00\xcd\x80\x31\xc0\xb0\x01\xcd\x80
    // hash(md5): f3efbf0af57106310a301d85a4fc8976
    static ui8 init_data[] = {
        //0x55,       // push ebp
        //0x89, 0xe5, // mov ebp, esp
        0xb8, 0x04, 0x00, 0x00, 0x00, // mov eax, 0x4
        0xbb, 0x01, 0x00, 0x00, 0x00, // mov ebx, 0x1
        0xb9, 0x10, 0xc0, 0x04, 0x08, // mov ecx, msg(0x804a000/0804c010)
        0xba, 0x22, 0x00, 0x00, 0x00, // mov edx, 0xe
        0xcd, 0x80,                   // int 0x80

        //0xb8, 0x01, 0x00, 0x00, 0x00, // mov eax, 0x1
        0x31, 0xc0, // xor    eax,eax
        0xb0, 0x01, // mov    al,0x1
        0xcd, 0x80
        //0xc9, // leave
        //0xc3, // ret
    };
    
    fun_ptr = (int(*)())init_data;
    char *text_ptr = &flag_1;

    ui32 *ptr_init_data = init_data + 11; // get 0x804a000
    *ptr_init_data = &flag_1;
    
    #ifdef __FLAG2_SEE__ || __SEE_ALL_FLAG__
    puts("\033[91m AABBAAAABBAAAAAABBAAAABBBBBBBBBBBBBB");
    puts("\033[92mflag2\033[39m: hash(\033[95mmd5\033[39m): \033[96m 117399eaab70b8181e2af61b3bed50d6\033[39m");
    #endif

    #ifdef __FLAG1_SEE__ || __SEE_ALL_FLAG__
    puts("\033[91m 0xb8\\x04\\x00\\x00\\x00\\xbb\\x01\\x00\\x00\\x00\\xb9\\x10\\xc0\\x04\\x08\\xba\\x0e\\x00\\x00\\x00\\xcd\\x80\\x31\\xc0\\xb0\\x01\\xcd\\x80");
    puts("\033[92mflag1\033[39m: hash(\033[95mmd5\033[39m): \033[96m f3efbf0af57106310a301d85a4fc8976\033[39m");

    #else 
    /*
     *  para imprimir la flag1(cambiar):
     *      if (1 == 0) fun_ptr();
     * 
     *  a:
     *      if (1 == 1) fun_ptr();
     * 
     *  O en su defecto use la macro __FLAG1_SEE__
     *  mediante -D__FLAG1_SEE__ al compilar u tmb valido
     *  -D__SEE_ALL_FLAG__
     */
    if (1 == 0) fun_ptr();
    #endif

    /*
     *  para imprimir la flag 2(descomentar):
     */
    //for (ui8 i = 0; i < sizeof(stack)/sizeof(ui8); i++) putchar(stack[i]);

    printf("\nexec main - sucess\n\n");
    return 0;
}
